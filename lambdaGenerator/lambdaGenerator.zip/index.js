var aws = require('aws-sdk');
var qr = require('qr-image');
var moment = require('moment');

const { Client } = require('pg');
const client = new Client();
const dbUrl = 'tcp://postgres:postgres@testingdb.cpcppg3yoc3a.us-east-1.rds.amazonaws.com:5432/carwashdb';

const bucket = 'lambda-coding';
const id = 'AKIA4XYGNBVQYHB7NBBU';
const secret = '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';

exports.handler =  function(event, context, callback) {
    var unixTime = moment().unix().toString();
    var code = qr.imageSync(unixTime, { type: 'png' });

    console.log(unixTime);
    const s3Bucket = new aws.S3({
        credentials : {
            accessKeyId: id,
            secretAccessKey: secret
        }
    });
    var fileName = unixTime + '.png';
    const params = {
        Bucket: bucket,
        Key: fileName,
        Body: code
    };
    s3Bucket.upload(params, function(err, data) {
        if (err) callback({
            statusCode: 500
        }, null);
        client.connect(dbUrl, (err, client, done) => {
            if (err) return callback({
                statusCode: 500
            }, null);
            client.query('INSERT INTO carwashschema.codigos (codeid, filename) VALUES ($1,$2)', [
                unixTime,
                fileName
            ], (err, result) => {
                if (err) return callback({
                    statusCode: 500
                }, null);
                client.end();
                return callback(null, {
                    statusCode: 200
                });
            });
        });
    });
}