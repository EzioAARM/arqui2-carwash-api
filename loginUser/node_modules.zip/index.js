var sha256 = require('sha256');
var jwt = require('jwt-simple');
var moment = require('moment');

var secret = 'mySecretTokenKey';

exports.handler = async (event) => {
    return new Promise((resolve, reject) => {
        readData(event.username, event.password)
            .then((data) => {
                console.log(data);
                resolve({
                    statusCode: 200,
                    token: jwt.encode({
                        sub: event.username,
                        iat: moment.unix(),
                        exp: moment.add(15, "days").unix()
                    }, secret)
                });
            })
            .catch((err) => {
                reject({
                    statusCode: 500,
                    error: err
                });
            })
    });
}

var readData = async (username, password) => {
    const { Client } = require('pg');
    const client = new Client();
    await client.connect();
    var queryText = "SELECT count(username) FROM carwashschema.usuarios WHERE username = $1 AND password = $2";
    const res = await client.query(
        queryText, 
        [
            username,
            sha256(password)
        ]);
    await client.end();
    return res;
};